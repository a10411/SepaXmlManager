﻿namespace SepaXmlManager.Api.Services
{
    public class BatchService
    {
    }
}
